<!--A Design by vivernlayouts
Author: vivernlayout
Author URL: http://vivernlayouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>


<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<script src="js/jquery.min.js"></script> 
</head>
<body>
	<div class="header">
		<div class="header_top">
			<div class="wrap">
			 <div class="logo">
				<h1>VIVERN SALON AND SPA</h1>
					</div>
			    <div class="call">
			    <p><img src="images/45.png" alt="" />Call US:+254-743-658-041</p>
			    </div>
			  			 
			<div class="clear"></div>
  		</div>
  	  </div>
	<div class="header_bottom">
		<div class="wrap">
	     	<div class="menu">
	     		<ul>
			    	<li class="active"><a href="index.php">Home</a></li>
			    	<li><a href="login.php">Login</a></li>
			    	<li><a href="Customer_Add.php">Register</a></li>	
<li><a href="services.php">Services</a></li>					
			    	<li><a href="about.php">About Us</a></li>
			    	<li><a href="feedback.php">Feedback</a></li>
			    	
			    	<div class="clear"></div>
     			</ul>
	     	</div>
	     	<div class="social-icons">
	     		<ul>
	     			<!----------------login------>
	     		</ul>
	     	</div>
	     	<div class="clear"></div>
	      </div>	     
	  </div>	


	
	     	<div class="clear"></div>
	      </div>	     
	  </div>	
	   <div class="strip"> </div>
    </div>  
 <div class="main">
    <div class="content">
    	 <div class="wrap">
    	 	<div class="services">
    	 		 <h2>Our Services</h2>
				<div class="section group">
				  <div class="col_1_of_4 span_1_of_4">
				  <img src="images/corporate-b.jpg" alt="" />
					<h3><span>Nail</span><br> Treatments</h3>
							<div class="services_list">
			          			<ul>
				                   <li><a href="">Nail Cut & Filing + Nail Polish</a></li>
				                    <li><a href="">Manicure - Regular	</a></li>
				                    <li><a href="">Absolute Moisturizing Gloves	</a></li>
				                    <li><a href="">Pedicure - Regular	</a></li>
				                    <li><a href="">Absolute Moisturizing Socks	</a></li>
				                </ul>
			          		</div>
			  		   </div>
				<div class="col_1_of_4 span_1_of_4">
				<img src="images/It helps keep your skin supple.jpg" alt="" />
					<h3><span>Facial</span><br>Treatment</h3>
							<div class="services_list">
								<ul>
				                   <li><a href="">Glistening Dew</a></li>
				                    <li><a href="">Eternal Hydro	</a></li>
				                    <li><a href="">Pureza</a></li>
				                    <li><a href="">Enlighten</a></li>
				                    <li><a href="">Oxygeneting</a></li>
									 <li><a href="">All Bright</a></li>
				                 <li><a href="">Facial</a></li>
				                </ul>
							</div>
					</div>
				<div class="col_1_of_4 span_1_of_4">
				<img src="images/44.jpg" alt=""   style=" height: 150px; width: 200px; "/>
					<h3><span>Hair</span><br>Treatments</h3>
							<div class="services_list">
			          			<ul>
			          				<li><a href="">Hair Cut </a></li>
				                    <li><a href="">Hair Smoothening</a></li>
				                   <li><a href="">Hair Curling </a></li>
				                    <li><a href="">Hair Designing </a></li>	
				                     <li><a href="">Hair Shambooing </a></li>	
									<li><a href="">Hair coloring	</a></li>
									<li><a href="">Hair straight	</a></li>									 
				                </ul>
			          		</div>
						</div>
				<div class="col_1_of_4 span_1_of_4">
				<img src="images/body-spa.png" alt="" style=" height: 150px; width: 200px;"/>
					<h3><span>Body</span><br>Spa</h3>
					   <div class="services_list">
								<ul>
				                   <li><a href="">Foot Reflexology </a></li>
				                    <li><a href="">Back Massage	</a></li>
				                    <li><a href="">Prenatel Massage	</a></li>
				                    <li><a href="">Swedish Massage 		</a></li>
				                    <li><a href="">Champi Head Massage </a></li>
										
	
	


				                </ul>
							</div>
					</div>
	            </div>
				<div class="col_1_of_4 span_1_of_4">
				<img src="images/33.jpg" alt="" style=" height: 150px; width: 200px;" />
					<h3><span>Body</span><br>Treatments</h3>
					   <div class="services_list">
								<ul>
				                   <li><a href="">Includes Cleansing, Scrubbing, Mask and Serum	</a></li>
				                    <li><a href="">Waxing -Upper Lip	</a></li>
				                    <li><a href="">Waxing - Full Body</a></li>
				                    <li><a href="">Threading - Eyebrow		</a></li>
				                </ul>
							</div>
					</div>
	            </div>
				<div class="col_1_of_4 span_1_of_4">
				<img src="images/gorgeous-brides-kandivali-east-mumbai-0b089.jpg" alt="" style=" height: 150px; width: 200px;" />
					<h3><span>Bridal</span><br>Makeup</h3>
					   <div class="services_list">
								<ul>
				                   <li><a href="">Mehendi </a></li>
				                    <li><a href="">Nail Art </a></li>
				                    <li><a href="">Saree Draping </a></li>
				                    <li><a href="">Make-up	</a></li>
				                    <li><a href="">Hair Styling </a></li>
				                </ul>
							</div>
					</div>
					<div class="col_1_of_4 span_1_of_4">
				<img src="images/61.jpg" alt="" style=" height: 150px; width: 200px; "/>
					<h3><span>Eye</span><br>Makeup</h3>
					   <div class="services_list">
								<ul>
				                   <li><a href="">Eye Shadow</a></li>
				                    <li><a href="">Eye Liner </a></li>
				                    <li><a href="">Brow Liner </a></li>
				                    <li><a href="">Mascara	</a></li>
				                    <li><a href="">Eye glass </a></li>
				                </ul>
							</div>
					</div>
	            </div>
				
	            <div class="section group example">
				<div class="col_1_of_2 span_1_of_2">
				   <h3>Highlights</h3>
 				</div>
				<div class="col_1_of_2 span_1_of_2">
				   <h3>Treatments</h3>
				   <div class="hair_treatment">
						<div class="treatment_img">
							<img src="images/bridal-makeup.png" alt="">
						</div>
						<div class="treatment-desc">
							<p>HAIR TREATMENTS</p>
						</div>
						<div class="clear"></div>
					</div>
					<div class="hair_treatment">
						<div class="treatment_img">
							<img src="images/eye-makeup.png" alt="">
						</div>
						<div class="treatment-desc">
							<p>EYE MAKEUP</p>
						</div>
						<div class="clear"></div>
					</div>
					<div class="hair_treatment">
						<div class="treatment_img">
							<img src="images/highlighting-hair.png" alt="">
						</div>
						<div class="treatment-desc">
							<p>BRIDAL MAKEUP</p>
						</div>
						<div class="clear"></div>
					</div>
					<div class="hair_treatment">
						<div class="treatment_img">
							<img src="images/pedicure.png" alt="">
						</div>
						<div class="treatment-desc">
							<p>SKIN TREATMENTS</p>
						</div>
						<div class="clear"></div>
					</div>
					<div class="hair_treatment">
						<div class="treatment_img">
							<img src="images/spa.png" alt="">
						</div>
						<div class="treatment-desc">
							<p>SPA TREATMENTS</p>
						</div>
						<div class="clear"></div>
					</div>
					<div class="hair_treatment">
						<div class="treatment_img">
							<img src="images/manicure.png" alt="">
						</div>
						<div class="treatment-desc">
							<p>NAIL TREATMENTS</p>
						</div>
						<div class="clear"></div>
					</div>
				</div>
		    </div>
     		 </div>
    		</div>
	    </div>
    </div>
 <div class="footer-strip"> </div>
 <div class="footer">
   	  <div class="wrap">
   	    <div class="footer_grides">
   	    	<div class="footer_grid1">
					<h3>Information</h3>
								<ul>
						            <li><a href="#">About Us</a></li>
						     		<li><a href="#">Privacy Policy</a></li>
						     		<li><a href="#">Newsletter</a></li>
						     		<li><a href="#">Site Map</a></li>						     		
						   	   </ul>	
						
					  	</div>
				<div class="footer_grid2">
					<h3>Get In Touch</h3>
							<div class="address">
							<ul>
						  	 <li>Vivern Salon & Spa</li>
						  	  <li>New City,</li>
						  	   <li>KENYA</li>
						  	 <li>www.vivern@gmail.com</li>
						  	 <li><span>Telephone :</span> +254743658041</li>
						  	 <li><span>Fax :</span> +254714440803</li>
						  </ul>
				   </div>				  
			     </div>
				<div class="footer_grid3">
					<h3>Our Company</h3>
						<div class="f_menu">
							   <ul>
						            <li><a href="#">About your Company</a></li>
						     		<li><a href="#">Terms &amp; conditions</a></li>
						     		<li><a href="#">News</a></li>
						     		<li><a href="#">Team of professionals</a></li>	
						     		<li><a href="#">Testimonials</a></li>					     		
						   	   </ul>
						</div>
				   </div>				
		  <div class="footer_grid4">
			<h3>Follow US</h3>
				<div class="img_list">
				    <ul>
					     <li><img src="images/28.png" alt=""><a href="#">Join Us on Facebook</a></li>
					     <li><img src="images/twitter.png" alt=""><a href="#">Follow Us on Twitter</a></li>
					     <li><img src="images/39.png" alt=""><a href="#">Share Us on Twitter</a></li>
				    </ul>
				</div>
		 </div>
	   <div class="clear"></div>
     </div>
    </div>
  </div>
<div class="copy_right">
				<p>Company Name © All rights Reseverd | Design by  <a href="http://vivernlayouts.com"> vivernLayouts </a></p>
		 </div>
</body>
</html>

