<?php
include 'customer_header.php';
?>
<marquee><b><font size="5">Welcome to you <?php echo $_SESSION['username'];?></b></font></marquee>
	     	<div class="clear"></div>
	      </div>	     
	  </div>	
	   
       <div class="slider">
       	 <div class="wrap">
       	   <div class="slider_top">         
         		<div class="slider_left">
				  <div class="wmuSlider example2">
					<div class="wmuSliderWrapper">
					<article> <img src="images/1 (2).jpg" alt="" /> </article>
					<article> <img src="images/2 (2).jpg" alt="" /> </article>
					<article> <img src="images/4 (2).jpg" alt="" />  </article>
					<article> <img src="images/3 (2).jpg" alt="" />  </article>
					</div>	
					<script src="js/jquery.wmuSlider.js"></script> 
					<script type="text/javascript" src="js/modernizr.custom.min.js"></script> 
					<script> 
					        $('.example2').wmuSlider({
					            touch: true,
					            animation: 'slide'
					        });   
					        
				    </script> 			
				 </div>
				</div>				
				   <div class="slider_right">
				      <img src="images/slideimg-1.jpg" alt="" />
				         <div class="sliderright-text">
				       	  <h3><span>New Facial</span><br />Treatments</h3>
				       </div>
				    </div>
				<div class="clear"></div>			 
		   </div>
			 <div class="slider_bottom">
			   <div class="section group">
				<div class="grid_1_of_3 images_1_of_3">
					<img src="images/discountimg1.jpg" width="418" height="279"  alt="" />
					 <div class="discount-text yellow">
					 	<h5>Get Up TO</h5>
				       	    <h1>20<b>%</b><span>off</span></h1>
				       	    <h3>Gro Massages</h3>
				      
				       </div>
				</div>
				<div class="grid_1_of_3 images_1_of_3">
					<img src="images/discountimg2.jpg" width="418" height="279" alt="" />
					<div class="discount-text green">
					 	<h5>Get Up TO</h5>
				       	    <h1>20<b>%</b><span>off</span></h1>
				       	    <h3>Makeup Services</h3>
				       	   	
				       </div>				       
	              </div>
				<div class="grid_1_of_3 images_1_of_3">
					<img src="images/discountimg3.jpg" width="418" height="279" alt="" />
					<div class="discount-text orange">
					 	<h5>Get Up TO</h5>
				       	    <h1>20<b>%</b><span>off</span></h1>
				       	    <h3>Stlish Groom</h3>
				       	 
				       </div>
				</div>
		    </div>
		  </div>
		</div> 
	 </div>
 <div class="main">
    <div class="content">
    	 <div class="wrap">
    	 	<div class="image group">
				<div class="grid images_3_of_1">
					<img src="images/welcome_img.jpg" alt="" />
				</div><center>
				<div class="grid span_2_of_3">
					<h3>We Work For <span>You!</span></h3>
					<p> </p>
			          <div class="treatment_list">
			          	<ul>
			          		<li><a href="#">Facial Treatment</a></li>
			          		<li><a href="#">Hair Treatment</a></li>
			          		<li><a href="#">Body Massage</a></li>
			          		<li><a href="#">Hair Care</a></li>
			          	</ul>
			          	<ul class="list2">
			          		<li><a href="#">Skin Care</a></li>
			          		<li><a href="#">Makeup Tratment</a></li>
			          		<li><a href="#">Bridal Makeup</a></li>
			          				          		
			          	</ul>
			          </div>
			   </div>
		   </div>
    	     <div class="pack-desc">
    	     	<h3>Beatuty Parlour  <span>Salon</span> SPA</h3>
    	     	  <p>There are many variations of passages of beatuty available but the majority</p>
    	     	     <div class="button"><a href="#">Purchase Our Spa Pack</a></div>
    	     </div>
	      
			<div class="spa_products">
				<h2>Latest Spa Products</h2>
				<div class="section group">
				<div class="products_1_of_3">
					  <img src="images/spa_product2.jpg" alt="" />
					  <h3>Facial Treatment </h3>
					<div class="read_more"><a href="#">Read More</a></div>
				</div>
				<div class="products_1_of_3">
					   <img src="images/spa_product1.jpg" alt="" />
					  <h3>Skin Treatment</h3>
					  <div class="read_more"><a href="#">Read More</a></div>
				</div>
				<div class="products_1_of_3">
					   <img src="images/spa_product3.jpg" alt="" />
					  <h3>Hair Treatment</h3>
					 <div class="read_more"><a href="#">Read More</a></div>
				</div>
			   </div>
		  </div>
       </div>
    </div>
 </div>
 <div class="footer-strip"> </div>
 <div class="footer">
   	  <div class="wrap">
   	    <div class="footer_grides">
   	    	<div class="footer_grid1">
					<h3>Information</h3>
								<ul>
						            <li><a href="#">About Us</a></li>
						     		<li><a href="#">Privacy Policy</a></li>
						     		<li><a href="#">Newsletter</a></li>
						     		<li><a href="#">Site Map</a></li>						     		
						   	   </ul>	
						
					  	</div>
				<div class="footer_grid2">
					<h3>Get In Touch</h3>
							<div class="address">
							<ul>
						  	  <li>Vivern Beatuty Parlour & Spa</li>
						  	  <li>New City</li>
						  	   <li>KENYA</li>
						  	 <li>www.vivern@gmail.com</li>
						  	 <li><span>Telephone :</span> +254-743-658-041</li>
						  	 <li><span>Fax :</span> +254-714-440-803</li>
						  </ul>
				   </div>				  
			     </div>
				<div class="footer_grid3">
					<h3>Our Company</h3>
						<div class="f_menu">
							   <ul>
						            <li><a href="#">About your Company</a></li>
						     		<li><a href="#">Terms &amp; conditions</a></li>
						     		<li><a href="#">News</a></li>
						     		<li><a href="#">Team of professionals</a></li>	
						     		<li><a href="#">Testimonials</a></li>					     		
						   	   </ul>
						</div>
				   </div>				
		  <div class="footer_grid4">
			<h3>Follow US</h3>
				<div class="img_list">
				    <ul>
					     <li><img src="images/facebook.png" alt=""><a href="#">Join Us on Facebook</a></li>
					     <li><img src="images/twitter.png" alt=""><a href="#">Follow Us on Twitter</a></li>
					     <li><img src="images/google-plus.png" alt=""><a href="#">Share Us on Twitter</a></li>
				    </ul>
				</div>
		 </div>
	   <div class="clear"></div>
     </div>
    </div>
  </div>
<div class="copy_right">
				<p>Company Name © All rights Reseverd | Design by  <a href="http://vivernlayouts.com"> VIVIAN SAMBU </a></p>
		 </div>
</body>
</html>
