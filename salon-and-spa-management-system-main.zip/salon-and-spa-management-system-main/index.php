﻿<!--A Design by vivian sambu
Author: vivian layout
Author URL: http://vivianlayouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<script src="js/jquery.min.js"></script> 
</head>
<body>
	<div class="header">
		<div class="header_top">
			<div class="wrap">
			 <div class="logo">
				<h1>VIVERN SALON AND SPA</h1>
					</div>
			    <div class="call">
			    	<p><img src="images/45.png" alt="" />Call US:+254-743-658-041</p>
			    </div>
			  			 
			<div class="clear"></div>
  		</div>
  	  </div>
	<div class="header_bottom">
		<div class="wrap">
	     	<div class="menu">
	     		<ul>
			    	<li class="active"><a href="index.php">Home</a></li>
			    	<li><a href="login.php">Login</a></li>
			    	<li><a href="Customer_Add.php">Register</a></li>	
					<li><a href="services.php">Services</a></li>					
			    	<li><a href="about.php">About Us</a></li>
					<li><a href="feedback.php">Feedback</a></li>
			    	
			    	
			    	<div class="clear"></div>
     			</ul>
	     	</div>
	     	<div class="social-icons">
	     		<ul>
	     			<!----------------login------>
	     		</ul>
	     	</div>
  	<div class="clear"></div>
	      </div>	     
	  </div>	
	   <div class="strip"> </div>
    </div> 
	     	
	 
    </div>  
       <div class="slider">
       	 <div class="wrap">
       	   <div class="slider_top">         
         		<div class="slider_left">
				  <div class="wmuSlider example2">
					<div class="wmuSliderWrapper">
					<article> <img src="images/5.jpg" alt="" height="350px" /> </article>
					<article> <img src="images/61.jpg" alt="" height="350px" /> </article>
					<article> <img src="images/4.jpg" alt="" height="550px" />  </article>
					<article> <img src="images/54.jpg" alt="" height="350px" />  </article>
					<article> <img src="images/banner1.jpg" alt="" height="350px" />  </article>
					<article> <img src="images/52.jpg" alt="" height="350px" />  </article>
					</div>	
					<script src="js/jquery.wmuSlider.js"></script> 
					<script type="text/javascript" src="js/modernizr.custom.min.js"></script> 
					<script> 
					        $('.example2').wmuSlider({
					            touch: true,
					            animation: 'slide'
					        });   
					        
				    </script> 			
				 </div>
				</div>				
				   <div class="slider_right">
				      <img src="images/9.jpg" alt="" height="350px" />
				         <div class="sliderright-text">
				       	  <h3><span>New Beauty</span><br />Tips</h3>
				       </div>
				    </div>
				<div class="clear"></div>			 
		   </div>
			 <div class="slider_bottom">
			   <div class="section group">
				
				
				
		    </div>
		  </div>
		</div> 
	 </div>
 <div class="main">
    <div class="content">
    	 <div class="wrap">
    	 	<div class="image group">
				
    	     	      
			<div class="spa_products">
				<h1>Latest Products</h1>
				<div class="section group">
				<div class="products_1_of_3">
					  <img src="images/62.jpg" alt="" />
					  <h3>L'Oreal Paris Infallible Lipstick</h3>
					  <p>The L'Oreal Paris Infallible Lipstick 741 Bold Bordeaux nourishes your lips and makes them soft and supple. It comes with a rich natural finish that offers a glamorous look. A L'Oreal Paris Bold comes free with this gloss. Benefits: . Non-Fading . Makes your lips feel soft and look luscious . Easy to use</p>
		
				</div>
				<div class="products_1_of_3">
					   <img src="images/63.jpg" alt="" />
					  <h3>Rose Face Powder, Soft Pink, 40g</h3>
					  <p>Bought to you from the house of Classics, The  Rose Powder is a classic must-have. Blush your cheeks with this  Rose Powder which has a light rosy fragrance & sunscreen to protect your soft, peachy skin. The  Rose Powder comes in two warm pink shades which you can pick according to your skin type and occasion.</p>
				
				</div>
				<div class="products_1_of_3">
					   <img src="images/64.jpg" alt="" />
					  <h3>Makeup-Kit</h3>
					  <p> This Is a Special Gift for Woman & Girls Case size: Combo Makeup Set (convenient to carry outdoor)Combo Makeup Sets by copy is the All in one set that has all you need for a professional makeup each individual makeup is manufactured with high quality materials and is offered at a very affordable price why pay more at edpartment store when you can have them all at one low price. Enjoy it</p>

				</div>
			   </div>
		  </div>
       </div>
    </div>
 </div>


		 </div>
	   <div class="clear"></div>
     </div>
    </div>
  </div>
  <div class="footer-strip"> </div>
 <div class="footer">
   	  <div class="wrap">
   	    <div class="footer_grides">
   	    	<div class="footer_grid1">
					<h3>Information</h3>
								<ul>
						            <li><a href="#">About Us</a></li>
						     		<li><a href="#">Privacy Policy</a></li>
						     		<li><a href="#">Newsletter</a></li>
						     		<li><a href="#">Site Map</a></li>						     		
						   	   </ul>	
						
					  	</div>
				<div class="footer_grid2">
					<h3>Get In Touch</h3>
							<div class="address">
							<ul>
						  	 <li>Vivern Salon,</li>
						  	  <li>New City,</li>
						  	   <li>KENYA.</li>
						  	 <li>www.vivern@gmail.com</li>
						  	 <li><span>Telephone :</span> +254743658041</li>
						  	 <li><span>Fax :</span> +254714440803</li>
						  </ul>
				   </div>				  
			     </div>
				<div class="footer_grid3">
					<h3>Our Company</h3>
						<div class="f_menu">
							   <ul>
						            <li><a href="#">About your Company</a></li>
						     		<li><a href="#">Terms &amp; conditions</a></li>
						     		<li><a href="#">News</a></li>
						     		<li><a href="#">Team of professionals</a></li>	
						     		<li><a href="#">Testimonials</a></li>					     		
						   	   </ul>
						</div>
				   </div>				
		  <div class="footer_grid4">
			<h3>Follow US</h3>
				<div class="img_list">
				    <ul>
					     <li><img src="images/28.png" alt=""><a href="#">Join Us on Facebook</a></li>
					     <li><img src="images/twitter.png" alt=""><a href="#">Follow Us on Twitter</a></li>
					     <li><img src="images/39.png" alt=""><a href="#">Share Us on Twitter</a></li>
				    </ul>
				</div>
		 </div>
	   <div class="clear"></div>
     </div>
    </div>
  </div>
<div class="copy_right">
				<p>© All rights Reseverd | Design by  <a href="http://vivernlayouts.com"> VIVERN SAMBU</a></p>
		 </div>
</body>
</html>

