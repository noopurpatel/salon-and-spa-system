#<?php
   $con=mysqli_connect('localhost','root','','salon_management(1)');
?>#

<?php
//all the variables defined here are accessible in all the files that include this one
#$con= new mysqli('localhost','root','','salon_managment(1)')or die("Could not connect to mysql".mysqli_error($con));

?>